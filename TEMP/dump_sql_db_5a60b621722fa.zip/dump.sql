-- MySQL dump 10.16  Distrib 10.1.29-MariaDB, for Win32 (AMD64)
--
-- Host: localhost    Database: mvc
-- ------------------------------------------------------
-- Server version	10.1.29-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `author`
--

DROP TABLE IF EXISTS `author`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `author` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `birth_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `author`
--

LOCK TABLES `author` WRITE;
/*!40000 ALTER TABLE `author` DISABLE KEYS */;
INSERT INTO `author` VALUES (1,'Skippy','Cabrales','1986-07-14'),(2,'Jobina','Cleyne','1962-08-08'),(3,'Demetria','Fasson','1990-06-04'),(4,'Reagan','Berre','1964-07-28'),(5,'Darin','Gymblett','1970-01-04'),(6,'Francoise','Chippindale','1998-05-08'),(7,'Travis','Seeley','1986-04-04'),(8,'Murray','Corhard','1962-08-02'),(9,'Tana','Elcox','1991-08-12'),(10,'Sebastian','Turneaux','1993-12-18'),(11,'Tomlin','Challin','2000-06-13'),(12,'Jimmy','Dallmann','1990-08-10'),(13,'Elias','Sangra','1965-12-19'),(14,'Friedrick','Hodges','1970-02-24'),(15,'Rowan','Hartless','1982-12-23'),(16,'Gayel','Annakin','1967-02-03'),(17,'Ines','Crissil','1986-07-07'),(18,'Vanessa','Bines','1994-06-09'),(19,'Page','Feronet','1970-05-13'),(20,'Melisandra','Siveyer','1967-12-08');
/*!40000 ALTER TABLE `author` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `author_book`
--

DROP TABLE IF EXISTS `author_book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `author_book` (
  `author_id` int(10) unsigned NOT NULL,
  `book_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`author_id`,`book_id`),
  KEY `book_id` (`book_id`),
  CONSTRAINT `author_book_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `author` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `author_book_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `book` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `author_book`
--

LOCK TABLES `author_book` WRITE;
/*!40000 ALTER TABLE `author_book` DISABLE KEYS */;
INSERT INTO `author_book` VALUES (1,23),(3,21),(3,25),(4,20),(5,24);
/*!40000 ALTER TABLE `author_book` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `book`
--

DROP TABLE IF EXISTS `book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `book` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `category_id` tinyint(3) unsigned NOT NULL,
  `is_active` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `book_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book`
--

LOCK TABLES `book` WRITE;
/*!40000 ALTER TABLE `book` DISABLE KEYS */;
INSERT INTO `book` VALUES (20,'Sweet Mud (Adama Meshuga\'at)','Morbi sem mauris, laoreet ut, rhoncus aliquet, pulvinar sed, nisl.',2024242.00,2,0),(21,'American Teen','Donec posuere metus vitae ipsum.',364.39,5,0),(23,'Thief of Bagdad, The','Etiam faucibus cursus urna.',616.68,3,0),(24,'Mamitas and lucky number','Donec ut dolor.or not.',308.65,5,0),(25,'Truth About Charlie, The','In quis justo.',230.32,8,1),(28,'Two white men','This is bed history...',300.00,8,1),(32,'EropeCity','Good book',333.00,2,0),(33,'ds','sd',1.00,4,0),(34,'12','121',99.00,3,0),(36,'wwww','www',3.00,3,0),(39,'23','3',3.00,2,0),(40,'23','3',3.00,2,0),(41,'ew','22222222222222222222222222222222222222222222222222222222',22.00,4,1);
/*!40000 ALTER TABLE `book` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `book_tegs`
--

DROP TABLE IF EXISTS `book_tegs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `book_tegs` (
  `book_id` int(10) unsigned NOT NULL,
  `teg_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`book_id`,`teg_id`),
  KEY `teg_id` (`teg_id`),
  CONSTRAINT `book_tegs_ibfk_1` FOREIGN KEY (`teg_id`) REFERENCES `teg` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `book_tegs_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `book` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book_tegs`
--

LOCK TABLES `book_tegs` WRITE;
/*!40000 ALTER TABLE `book_tegs` DISABLE KEYS */;
INSERT INTO `book_tegs` VALUES (20,4),(20,10),(20,12),(20,13),(20,14),(21,1),(21,3),(23,2),(23,4),(23,6),(23,7),(23,14),(24,1),(24,7),(24,9),(24,11);
/*!40000 ALTER TABLE `book_tegs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Thriller'),(2,'Drama'),(3,'Sci-Fi'),(4,'Action'),(5,'Comedy'),(6,'Adventure'),(7,'Animation'),(8,'Fantasy'),(9,'Documentary'),(10,'Fantasy'),(11,'Romance'),(12,'Children'),(13,'Musical'),(14,'Mystery');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `message` text,
  `ip_address` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback`
--

LOCK TABLES `feedback` WRITE;
/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
INSERT INTO `feedback` VALUES (106,'Ð¹Ñ†',NULL,'Ð¹Ñ†',NULL,'2017-12-15 16:31:14'),(107,'nis@nis.com','12','12','127.0.0.1','2017-12-15 17:59:00');
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teg`
--

DROP TABLE IF EXISTS `teg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teg` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `word` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teg`
--

LOCK TABLES `teg` WRITE;
/*!40000 ALTER TABLE `teg` DISABLE KEYS */;
INSERT INTO `teg` VALUES (1,'love'),(2,'life'),(3,'inspirational'),(4,'philosophy'),(5,'die'),(6,'happiness'),(7,'truth'),(8,'hope'),(9,'quotes'),(10,'erat'),(11,'sagittis'),(12,'funny'),(13,'spirituality'),(14,'writing');
/*!40000 ALTER TABLE `teg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin@admin.com','$2y$10$82gil6YwJgbuaYmZ4fUseOiAw9UMWQDuRP50iOuPBFoFrCt6rAt02'),(8,'as','$2y$10$oYABxiZoLpw4ko4P5M8RCOADiQEhHmjPzZhXcHuZW4mqhR8RUe.Zu'),(9,'11','$2y$10$yNzienP30A13wjBvHHG9xOvM96v57EHZ/Wyqc3nG9T.WCF5Uwcaea'),(10,'12','$2y$10$IRz4EDu7HZuBt3los1flx.PC7pmw69Ux4Aqj5msB8PiuD6hk0z23O');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-01-18 16:58:41
